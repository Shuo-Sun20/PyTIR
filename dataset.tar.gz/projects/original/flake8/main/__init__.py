"""Module containing the logic for the Flake8 entry-points."""
from __future__ import annotations