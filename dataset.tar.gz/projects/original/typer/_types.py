from enum import Enum
from typing import Generic, TypeVar, Union
import click
ParamTypeValue = TypeVar('ParamTypeValue')

class TyperChoice(click.Choice, Generic[ParamTypeValue]):

    def normalize_choice(self, choice: ParamTypeValue, ctx: Union[click.Context, None]) -> str:
        normed_value = str(choice.value) if isinstance(choice, Enum) else str(choice)
        if ctx is not None and ctx.token_normalize_func is not None:
            normed_value = ctx.token_normalize_func(normed_value)
        if not self.case_sensitive:
            normed_value = normed_value.casefold()
        return normed_value