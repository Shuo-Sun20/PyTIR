"""Custom docutils writer for LaTeX.

Much of this code is adapted from Dave Kuhlman's "docpy" writer from his
docutils sandbox.
"""
from __future__ import annotations
import re
from collections import defaultdict
from collections.abc import Iterable
from os import path
from typing import TYPE_CHECKING, Any, ClassVar, cast
from docutils import nodes, writers#type: ignore
from sphinx import addnodes, highlighting
from sphinx.errors import SphinxError
from sphinx.locale import _, __, admonitionlabels
from sphinx.util import logging, texescape
from sphinx.util.docutils import SphinxTranslator
from sphinx.util.index_entries import split_index_msg
from sphinx.util.nodes import clean_astext, get_prev_node
from sphinx.util.template import LaTeXRenderer
from sphinx.util.texescape import tex_replace_map
try:
    from docutils.utils.roman import toRoman#type: ignore
except ImportError:
    from roman import toRoman
if TYPE_CHECKING:
    from docutils.nodes import Element, Node, Text#type: ignore
    from sphinx.builders.latex import LaTeXBuilder
    from sphinx.builders.latex.theming import Theme
    from sphinx.domains import IndexEntry
logger = logging.getLogger(__name__)
MAX_CITATION_LABEL_LENGTH = 8
LATEXSECTIONNAMES = ['part', 'chapter', 'section', 'subsection', 'subsubsection', 'paragraph', 'subparagraph']
ENUMERATE_LIST_STYLE = defaultdict(lambda : '\\arabic', {'arabic': '\\arabic', 'loweralpha': '\\alph', 'upperalpha': '\\Alph', 'lowerroman': '\\roman', 'upperroman': '\\Roman'})
CR = '\n'
BLANKLINE = '\n\n'
EXTRA_RE = re.compile('^(.*\\S)\\s+\\(([^()]*)\\)\\s*$')

class collected_footnote(nodes.footnote):
    """Footnotes that are collected are assigned this class."""

class UnsupportedError(SphinxError):
    category = 'Markup is unsupported in LaTeX'

class LaTeXWriter(writers.Writer):
    supported = ('sphinxlatex',)
    settings_spec = ('LaTeX writer options', '', (('Document name', ['--docname'], {'default': ''}), ('Document class', ['--docclass'], {'default': 'manual'}), ('Author', ['--author'], {'default': ''})))
    settings_defaults: ClassVar[dict[str, Any]] = {}
    theme: Theme

    def __init__(self, builder: LaTeXBuilder) -> None:
        super().__init__()
        self.builder = builder

    def translate(self) -> None:
        assert isinstance(self.document, nodes.document)
        visitor = self.builder.create_translator(self.document, self.builder, self.theme)
        self.document.walkabout(visitor)
        self.output = cast(LaTeXTranslator, visitor).astext()

class Table:
    """A table data"""

    def __init__(self, node: Element) -> None:
        self.header: list[str] = []
        self.body: list[str] = []
        self.align = node.get('align', 'default')
        self.classes: list[str] = node.get('classes', [])
        self.styles: list[str] = []
        if 'standard' in self.classes:
            self.styles.append('standard')
        elif 'borderless' in self.classes:
            self.styles.append('borderless')
        elif 'booktabs' in self.classes:
            self.styles.append('booktabs')
        if 'nocolorrows' in self.classes:
            self.styles.append('nocolorrows')
        elif 'colorrows' in self.classes:
            self.styles.append('colorrows')
        self.colcount = 0
        self.colspec: str = ''
        if 'booktabs' in self.styles or 'borderless' in self.styles:
            self.colsep: str | None = ''
        elif 'standard' in self.styles:
            self.colsep = '|'
        else:
            self.colsep = None
        self.colwidths: list[int] = []
        self.has_problematic = False
        self.has_oldproblematic = False
        self.has_verbatim = False
        self.caption: list[str] = []
        self.stubs: list[int] = []
        self.col = 0
        self.row = 0
        self.cells: dict[tuple[int, int], int] = defaultdict(int)
        self.cell_id = 0

    def is_longtable(self) -> bool:
        """True if and only if table uses longtable environment."""
        return self.row > 30 or 'longtable' in self.classes

    def get_table_type(self) -> str:
        """Returns the LaTeX environment name for the table.

        The class currently supports:

        * longtable
        * tabular
        * tabulary
        """
        if self.is_longtable():
            return 'longtable'
        elif self.has_verbatim:
            return 'tabular'
        elif self.colspec:
            return 'tabulary'
        elif self.has_problematic or (self.colwidths and 'colwidths-given' in self.classes):
            return 'tabular'
        else:
            return 'tabulary'

    def get_colspec(self) -> str:
        """Returns a column spec of table.

        This is what LaTeX calls the 'preamble argument' of the used table environment.

        .. note::

           The ``\\\\X`` and ``T`` column type specifiers are defined in
           ``sphinxlatextables.sty``.
        """
        if self.colspec:
            return self.colspec
        _colsep = self.colsep
        assert _colsep is not None
        if self.colwidths and 'colwidths-given' in self.classes:
            total = sum(self.colwidths)
            colspecs = ['\\X{%d}{%d}' % (width, total) for width in self.colwidths]
            return f'{{{_colsep}{_colsep.join(colspecs)}{_colsep}}}' + CR
        elif self.has_problematic:
            return '{%s*{%d}{\\X{1}{%d}%s}}' % (_colsep, self.colcount, self.colcount, _colsep) + CR
        elif self.get_table_type() == 'tabulary':
            return '{' + _colsep + ('T' + _colsep) * self.colcount + '}' + CR
        elif self.has_oldproblematic:
            return '{%s*{%d}{\\X{1}{%d}%s}}' % (_colsep, self.colcount, self.colcount, _colsep) + CR
        else:
            return '{' + _colsep + ('l' + _colsep) * self.colcount + '}' + CR

    def add_cell(self, height: int, width: int) -> None:
        """Adds a new cell to a table.

        It will be located at current position: (``self.row``, ``self.col``).
        """
        self.cell_id += 1
        for col in range(width):
            for row in range(height):
                assert self.cells[self.row + row, self.col + col] == 0
                self.cells[self.row + row, self.col + col] = self.cell_id

    def cell(self, row: int | None=None, col: int | None=None) -> TableCell | None:
        """Returns a cell object (i.e. rectangular area) containing given position.

        If no option arguments: ``row`` or ``col`` are given, the current position;
        ``self.row`` and ``self.col`` are used to get a cell object by default.
        """
        try:
            if row is None:
                row = self.row
            if col is None:
                col = self.col
            return TableCell(self, row, col)
        except IndexError:
            return None

class TableCell:
    """Data of a cell in a table."""

    def __init__(self, table: Table, row: int, col: int) -> None:
        if table.cells[row, col] == 0:
            raise IndexError
        self.table = table
        self.cell_id = table.cells[row, col]
        self.row = row
        self.col = col
        while table.cells[self.row - 1, self.col] == self.cell_id:
            self.row -= 1
        while table.cells[self.row, self.col - 1] == self.cell_id:
            self.col -= 1

    @property
    def width(self) -> int:
        """Returns the cell width."""
        width = 0
        while self.table.cells[self.row, self.col + width] == self.cell_id:
            width += 1
        return width

    @property
    def height(self) -> int:
        """Returns the cell height."""
        height = 0
        while self.table.cells[self.row + height, self.col] == self.cell_id:
            height += 1
        return height

def escape_abbr(text: str) -> str:
    """Adjust spacing after abbreviations."""
    return re.sub('\\.(?=\\s|$)', '.\\@', text)

def rstdim_to_latexdim(width_str: str, scale: int=100) -> str:
    """Convert `width_str` with rst length to LaTeX length."""
    match = re.match('^(\\d*\\.?\\d*)\\s*(\\S*)$', width_str)
    if not match:
        raise ValueError
    res = width_str
    (amount, unit) = match.groups()[:2]
    if scale == 100:
        float(amount)
        if unit in ('', 'px'):
            res = '%s\\sphinxpxdimen' % amount
        elif unit == 'pt':
            res = '%sbp' % amount
        elif unit == '%':
            res = '%.3f\\linewidth' % (float(amount) / 100.0)
    else:
        amount_float = float(amount) * scale / 100.0
        if unit in ('', 'px'):
            res = '%.5f\\sphinxpxdimen' % amount_float
        elif unit == 'pt':
            res = '%.5fbp' % amount_float
        elif unit == '%':
            res = '%.5f\\linewidth' % (amount_float / 100.0)
        else:
            res = f'{amount_float:.5f}{unit}'
    return res

class LaTeXTranslator(SphinxTranslator):
    builder: LaTeXBuilder
    secnumdepth = 2
    ignore_missing_images = False

    def __init__(self, document: nodes.document, builder: LaTeXBuilder, theme: Theme) -> None:
        super().__init__(document, builder)
        self.body: list[str] = []
        self.theme = theme
        self.in_title = 0
        self.in_production_list = 0
        self.in_footnote = 0
        self.in_caption = 0
        self.in_term = 0
        self.needs_linetrimming = 0
        self.in_minipage = 0
        self.no_latex_floats = 0
        self.first_document = 1
        self.this_is_the_title = 1
        self.literal_whitespace = 0
        self.in_parsed_literal = 0
        self.compact_list = 0
        self.first_param = 0
        self.in_desc_signature = False
        sphinxpkgoptions = []
        self.elements = self.builder.context.copy()
        self.sectionnames = LATEXSECTIONNAMES.copy()
        if self.theme.toplevel_sectioning == 'section':
            self.sectionnames.remove('chapter')
        self.top_sectionlevel = 1
        if self.config.latex_toplevel_sectioning:
            try:
                self.top_sectionlevel = self.sectionnames.index(self.config.latex_toplevel_sectioning)
            except ValueError:
                logger.warning(__('unknown %r toplevel_sectioning for class %r'), self.config.latex_toplevel_sectioning, self.theme.docclass)
        if self.config.numfig:
            self.numfig_secnum_depth = self.config.numfig_secnum_depth
            if self.numfig_secnum_depth > 0:
                if len(self.sectionnames) < len(LATEXSECTIONNAMES) and self.top_sectionlevel > 0:
                    self.numfig_secnum_depth += self.top_sectionlevel
                else:
                    self.numfig_secnum_depth += self.top_sectionlevel - 1
                self.numfig_secnum_depth = min(self.numfig_secnum_depth, len(LATEXSECTIONNAMES) - 1)
                sphinxpkgoptions.append('numfigreset=%s' % self.numfig_secnum_depth)
            else:
                sphinxpkgoptions.append('nonumfigreset')
        if self.config.numfig and self.config.math_numfig:
            sphinxpkgoptions.extend(['mathnumfig', 'mathnumsep={%s}' % self.config.math_numsep])
        if self.config.language not in {'en', 'ja'} and 'fncychap' not in self.config.latex_elements:
            self.elements['fncychap'] = '\\usepackage[Sonny]{fncychap}' + CR + '\\ChNameVar{\\Large\\normalfont\\sffamily}' + CR + '\\ChTitleVar{\\Large\\normalfont\\sffamily}'
        self.babel = self.builder.babel
        if not self.babel.is_supported_language():
            logger.warning(__('no Babel option known for language %r'), self.config.language)
        minsecnumdepth = self.secnumdepth
        if self.document.get('tocdepth'):
            tocdepth = self.document.get('tocdepth', 999) + self.top_sectionlevel - 2
            if len(self.sectionnames) < len(LATEXSECTIONNAMES) and self.top_sectionlevel > 0:
                tocdepth += 1
            if tocdepth > len(LATEXSECTIONNAMES) - 2:
                logger.warning(__('too large :maxdepth:, ignored.'))
                tocdepth = len(LATEXSECTIONNAMES) - 2
            self.elements['tocdepth'] = '\\setcounter{tocdepth}{%d}' % tocdepth
            minsecnumdepth = max(minsecnumdepth, tocdepth)
        if self.config.numfig and self.config.numfig_secnum_depth > 0:
            minsecnumdepth = max(minsecnumdepth, self.numfig_secnum_depth - 1)
        if minsecnumdepth > self.secnumdepth:
            self.elements['secnumdepth'] = '\\setcounter{secnumdepth}{%d}' % minsecnumdepth
        contentsname = document.get('contentsname')
        if contentsname:
            self.elements['contentsname'] = self.babel_renewcommand('\\contentsname', contentsname)
        if self.elements['maxlistdepth']:
            sphinxpkgoptions.append('maxlistdepth=%s' % self.elements['maxlistdepth'])
        if sphinxpkgoptions:
            self.elements['sphinxpkgoptions'] = '[,%s]' % ','.join(sphinxpkgoptions)
        if self.elements['sphinxsetup']:
            self.elements['sphinxsetup'] = '\\sphinxsetup{%s}' % self.elements['sphinxsetup']
        if self.elements['extraclassoptions']:
            self.elements['classoptions'] += ',' + self.elements['extraclassoptions']
        self.highlighter = highlighting.PygmentsBridge('latex', self.config.pygments_style, latex_engine=self.config.latex_engine)
        self.context: list[Any] = []
        self.descstack: list[str] = []
        self.tables: list[Table] = []
        self.next_table_colspec: str | None = None
        self.bodystack: list[list[str]] = []
        self.footnote_restricted: Element | None = None
        self.pending_footnotes: list[nodes.footnote_reference] = []
        self.curfilestack: list[str] = []
        self.handled_abbrs: set[str] = set()

    def pushbody(self, newbody: list[str]) -> None:
        self.bodystack.append(self.body)
        self.body = newbody

    def popbody(self) -> list[str]:
        body = self.body
        self.body = self.bodystack.pop()
        return body

    def astext(self) -> str:
        self.elements.update({'body': ''.join(self.body), 'indices': self.generate_indices()})
        return self.render('latex.tex.jinja', self.elements)

    def hypertarget(self, id: str, withdoc: bool=True, anchor: bool=True) -> str:
        if withdoc:
            id = self.curfilestack[-1] + ':' + id
        escaped_id = self.idescape(id)
        return ('\\phantomsection' if anchor else '') + '\\label{%s}' % escaped_id

    def hypertarget_to(self, node: Element, anchor: bool=False) -> str:
        labels = ''.join((self.hypertarget(node_id, anchor=False) for node_id in node['ids']))
        if anchor:
            return '\\phantomsection' + labels
        else:
            return labels

    def hyperlink(self, id: str) -> str:
        return '{\\hyperref[%s]{' % self.idescape(id)

    def hyperpageref(self, id: str) -> str:
        return '\\autopageref*{%s}' % self.idescape(id)

    def escape(self, s: str) -> str:
        return texescape.escape(s, self.config.latex_engine)

    def idescape(self, id: str) -> str:
        id = str(id).translate(tex_replace_map)
        id = id.encode('ascii', 'backslashreplace').decode('ascii')
        return '\\detokenize{%s}' % id.replace('\\', '_')

    def babel_renewcommand(self, command: str, definition: str) -> str:
        if self.elements['multilingual']:
            prefix = '\\addto\\captions%s{' % self.babel.get_language()
            suffix = '}'
        else:
            prefix = ''
            suffix = ''
        return f'{prefix}\\renewcommand{{{command}}}{{{definition}}}{suffix}' + CR

    def generate_indices(self) -> str:

        def generate(content: list[tuple[str, list[IndexEntry]]], collapsed: bool) -> None:
            ret.append('\\begin{sphinxtheindex}' + CR)
            ret.append('\\let\\bigletter\\sphinxstyleindexlettergroup' + CR)
            for (i, (letter, entries)) in enumerate(content):
                if i > 0:
                    ret.append('\\indexspace' + CR)
                ret.append('\\bigletter{%s}' % self.escape(letter) + CR)
                for entry in entries:
                    if not entry[3]:
                        continue
                    ret.append('\\item\\relax\\sphinxstyleindexentry{%s}' % self.encode(entry[0]))
                    if entry[4]:
                        ret.append('\\sphinxstyleindexextra{%s}' % self.encode(entry[4]))
                    ret.append('\\sphinxstyleindexpageref{%s:%s}' % (entry[2], self.idescape(entry[3])) + CR)
            ret.append('\\end{sphinxtheindex}' + CR)
        ret = []
        if (indices_config := self.config.latex_domain_indices):
            if not isinstance(indices_config, bool):
                check_names = True
                indices_config = frozenset(indices_config)
            else:
                check_names = False
            for domain in self.builder.env.domains.sorted():
                for index_cls in domain.indices:
                    index_name = f'{domain.name}-{index_cls.name}'
                    if check_names and index_name not in indices_config:
                        continue
                    (content, collapsed) = index_cls(domain).generate(self.builder.docnames)
                    if content:
                        ret.append('\\renewcommand{\\indexname}{%s}' % index_cls.localname + CR)
                        generate(content, collapsed)
        return ''.join(ret)

    def render(self, template_name: str, variables: dict[str, Any]) -> str:
        renderer = LaTeXRenderer(latex_engine=self.config.latex_engine)
        for template_dir in self.config.templates_path:
            template = path.join(self.builder.confdir, template_dir, template_name)
            if path.exists(template):
                return renderer.render(template, variables)
            elif template.endswith('.jinja'):
                legacy_template = template.removesuffix('.jinja') + '_t'
                if path.exists(legacy_template):
                    logger.warning(__('template %s not found; loading from legacy %s instead'), template_name, legacy_template)
                    return renderer.render(legacy_template, variables)
        return renderer.render(template_name, variables)

    @property
    def table(self) -> Table | None:
        """Get current table."""
        if self.tables:
            return self.tables[-1]
        else:
            return None

    def visit_document(self, node: Element) -> None:
        self.curfilestack.append(node.get('docname', ''))
        if self.first_document == 1:
            self.first_document = 0
        elif self.first_document == 0:
            self.body.append(CR + '\\appendix' + CR)
            self.first_document = -1
        if 'docname' in node:
            self.body.append(self.hypertarget(':doc'))
        self.sectionlevel = self.top_sectionlevel - 1

    def depart_document(self, node: Element) -> None:
        pass

    def visit_start_of_file(self, node: Element) -> None:
        self.curfilestack.append(node['docname'])
        self.body.append(CR + '\\sphinxstepscope' + CR)

    def depart_start_of_file(self, node: Element) -> None:
        self.curfilestack.pop()

    def visit_section(self, node: Element) -> None:
        if not self.this_is_the_title:
            self.sectionlevel += 1
        self.body.append(BLANKLINE)

    def depart_section(self, node: Element) -> None:
        self.sectionlevel = max(self.sectionlevel - 1, self.top_sectionlevel - 1)

    def visit_problematic(self, node: Element) -> None:
        self.body.append('{\\color{red}\\bfseries{}')

    def depart_problematic(self, node: Element) -> None:
        self.body.append('}')

    def visit_topic(self, node: Element) -> None:
        self.in_minipage += 1
        if 'contents' in node.get('classes', []):
            self.body.append(CR + '\\begin{sphinxcontents}' + CR)
            self.context.append('\\end{sphinxcontents}' + CR)
        else:
            self.body.append(CR + '\\begin{sphinxtopic}' + CR)
            self.context.append('\\end{sphinxtopic}' + CR)

    def depart_topic(self, node: Element) -> None:
        self.in_minipage -= 1
        self.body.append(self.context.pop())

    def visit_sidebar(self, node: Element) -> None:
        self.in_minipage += 1
        self.body.append(CR + '\\begin{sphinxsidebar}' + CR)
        self.context.append('\\end{sphinxsidebar}' + CR)
    depart_sidebar = depart_topic

    def visit_glossary(self, node: Element) -> None:
        pass

    def depart_glossary(self, node: Element) -> None:
        pass

    def visit_productionlist(self, node: Element) -> None:
        self.body.append(BLANKLINE)
        self.body.append('\\begin{productionlist}' + CR)
        self.in_production_list = 1

    def depart_productionlist(self, node: Element) -> None:
        self.body.append('\\end{productionlist}' + BLANKLINE)
        self.in_production_list = 0

    def visit_production(self, node: Element) -> None:
        if node['tokenname']:
            tn = node['tokenname']
            self.body.append(self.hypertarget('grammar-token-' + tn))
            self.body.append('\\production{%s}{' % self.encode(tn))
        else:
            self.body.append('\\productioncont{')

    def depart_production(self, node: Element) -> None:
        self.body.append('}' + CR)

    def visit_transition(self, node: Element) -> None:
        self.body.append(self.elements['transition'])

    def depart_transition(self, node: Element) -> None:
        pass

    def visit_title(self, node: Element) -> None:
        parent = node.parent
        if isinstance(parent, addnodes.seealso):
            raise nodes.SkipNode
        if isinstance(parent, nodes.section):
            if self.this_is_the_title:
                if len(node.children) != 1 and (not isinstance(node.children[0], nodes.Text)):
                    logger.warning(__('document title is not a single Text node'), location=node)
                if not self.elements['title']:
                    self.elements['title'] = self.escape(node.astext())
                self.this_is_the_title = 0
                raise nodes.SkipNode
            short = ''
            if any(node.findall(nodes.image)):
                short = '[%s]' % self.escape(' '.join(clean_astext(node).split()))
            try:
                self.body.append(f'\\{self.sectionnames[self.sectionlevel]}{short}{{')
            except IndexError:
                self.body.append(f'\\{self.sectionnames[-1]}{short}{{')
            self.context.append('}' + CR + self.hypertarget_to(node.parent))
        elif isinstance(parent, nodes.topic):
            if 'contents' in parent.get('classes', []):
                self.body.append('\\sphinxstylecontentstitle{')
            else:
                self.body.append('\\sphinxstyletopictitle{')
            self.context.append('}' + CR)
        elif isinstance(parent, nodes.sidebar):
            self.body.append('\\sphinxstylesidebartitle{')
            self.context.append('}' + CR)
        elif isinstance(parent, nodes.Admonition):
            self.body.append('{')
            self.context.append('}' + CR)
        elif isinstance(parent, nodes.table):
            self.pushbody([])
        else:
            logger.warning(__('encountered title node not in section, topic, table, admonition or sidebar'), location=node)
            self.body.append('\\sphinxstyleothertitle{')
            self.context.append('}' + CR)
        self.in_title = 1

    def depart_title(self, node: Element) -> None:
        self.in_title = 0
        if isinstance(node.parent, nodes.table):
            assert self.table is not None
            self.table.caption = self.popbody()
        else:
            self.body.append(self.context.pop())

    def visit_subtitle(self, node: Element) -> None:
        if isinstance(node.parent, nodes.sidebar):
            self.body.append('\\sphinxstylesidebarsubtitle{')
            self.context.append('}' + CR)
        else:
            self.context.append('')

    def depart_subtitle(self, node: Element) -> None:
        self.body.append(self.context.pop())

    def visit_desc(self, node: Element) -> None:
        if self.config.latex_show_urls == 'footnote':
            self.body.append(BLANKLINE)
            self.body.append('\\begin{savenotes}\\begin{fulllineitems}' + CR)
        else:
            self.body.append(BLANKLINE)
            self.body.append('\\begin{fulllineitems}' + CR)
        if self.table:
            self.table.has_problematic = True

    def depart_desc(self, node: Element) -> None:
        if self.in_desc_signature:
            self.body.append(CR + '\\pysigstopsignatures')
            self.in_desc_signature = False
        if self.config.latex_show_urls == 'footnote':
            self.body.append(CR + '\\end{fulllineitems}\\end{savenotes}' + BLANKLINE)
        else:
            self.body.append(CR + '\\end{fulllineitems}' + BLANKLINE)

    def _visit_signature_line(self, node: Element) -> None:

        def next_sibling(e: Node) -> Node | None:
            try:
                return e.parent[e.parent.index(e) + 1]
            except (AttributeError, IndexError):
                return None

        def has_multi_line(e: Element) -> bool:
            return e.get('multi_line_parameter_list')
        self.has_tp_list = False
        self.orphan_tp_list = False
        for child in node:
            if isinstance(child, addnodes.desc_type_parameter_list):
                self.has_tp_list = True
                multi_tp_list = has_multi_line(child)
                arglist = next_sibling(child)
                if isinstance(arglist, addnodes.desc_parameterlist):
                    multi_arglist = has_multi_line(arglist)
                else:
                    self.orphan_tp_list = True
                    multi_arglist = False
                if multi_tp_list:
                    if multi_arglist:
                        self.body.append(CR + '\\pysigwithonelineperargwithonelinepertparg' + CR + '{')
                    else:
                        self.body.append(CR + '\\pysiglinewithargsretwithonelinepertparg' + CR + '{')
                elif multi_arglist:
                    self.body.append(CR + '\\pysigwithonelineperargwithtypelist' + CR + '{')
                else:
                    self.body.append(CR + '\\pysiglinewithargsretwithtypelist' + CR + '{')
                break
            if isinstance(child, addnodes.desc_parameterlist):
                if has_multi_line(child):
                    self.body.append(CR + '\\pysigwithonelineperarg' + CR + '{')
                else:
                    self.body.append(CR + '\\pysiglinewithargsret' + CR + '{')
                break
        else:
            self.body.append(CR + '\\pysigline' + CR + '{')

    def _depart_signature_line(self, node: Element) -> None:
        self.body.append('}')

    def visit_desc_signature(self, node: Element) -> None:
        hyper = ''
        if node.parent['objtype'] != 'describe' and node['ids']:
            for id in node['ids']:
                hyper += self.hypertarget(id)
        self.body.append(hyper)
        if not self.in_desc_signature:
            self.in_desc_signature = True
            self.body.append(CR + '\\pysigstartsignatures')
        if not node.get('is_multiline'):
            self._visit_signature_line(node)
        else:
            self.body.append(CR + '\\pysigstartmultiline')

    def depart_desc_signature(self, node: Element) -> None:
        if not node.get('is_multiline'):
            self._depart_signature_line(node)
        else:
            self.body.append(CR + '\\pysigstopmultiline')

    def visit_desc_signature_line(self, node: Element) -> None:
        self._visit_signature_line(node)

    def depart_desc_signature_line(self, node: Element) -> None:
        self._depart_signature_line(node)

    def visit_desc_content(self, node: Element) -> None:
        assert self.in_desc_signature
        self.body.append(CR + '\\pysigstopsignatures')
        self.in_desc_signature = False

    def depart_desc_content(self, node: Element) -> None:
        pass

    def visit_desc_inline(self, node: Element) -> None:
        self.body.append('\\sphinxcode{\\sphinxupquote{')

    def depart_desc_inline(self, node: Element) -> None:
        self.body.append('}}')

    def visit_desc_name(self, node: Element) -> None:
        self.body.append('\\sphinxbfcode{\\sphinxupquote{')
        self.literal_whitespace += 1

    def depart_desc_name(self, node: Element) -> None:
        self.body.append('}}')
        self.literal_whitespace -= 1

    def visit_desc_addname(self, node: Element) -> None:
        self.body.append('\\sphinxcode{\\sphinxupquote{')
        self.literal_whitespace += 1

    def depart_desc_addname(self, node: Element) -> None:
        self.body.append('}}')
        self.literal_whitespace -= 1

    def visit_desc_type(self, node: Element) -> None:
        pass

    def depart_desc_type(self, node: Element) -> None:
        pass

    def visit_desc_returns(self, node: Element) -> None:
        self.body.append('{ $\\rightarrow$ ')

    def depart_desc_returns(self, node: Element) -> None:
        self.body.append('}')

    def _visit_sig_parameter_list(self, node: Element, parameter_group: type[Element]) -> None:
        """Visit a signature parameters or type parameters list.

        The *parameter_group* value is the type of a child node acting as a required parameter
        or as a set of contiguous optional parameters.

        The caller is responsible for closing adding surrounding LaTeX macro argument start
        and stop tokens.
        """
        self.is_first_param = True
        self.optional_param_level = 0
        self.params_left_at_level = 0
        self.param_group_index = 0
        self.list_is_required_param = [isinstance(c, parameter_group) for c in node.children]
        self.required_params_left = sum(self.list_is_required_param)
        self.param_separator = '\\sphinxparamcomma '
        self.multi_line_parameter_list = node.get('multi_line_parameter_list', False)

    def visit_desc_parameterlist(self, node: Element) -> None:
        if self.has_tp_list:
            if self.orphan_tp_list:
                self.body.append('}' + CR + '{')
                return
        else:
            self.body.append('}' + CR + '{')
        self._visit_sig_parameter_list(node, addnodes.desc_parameter)

    def depart_desc_parameterlist(self, node: Element) -> None:
        assert not self.orphan_tp_list
        self.body.append('}' + CR + '{')

    def visit_desc_type_parameter_list(self, node: Element) -> None:
        self.body.append('}' + CR + '{')
        self._visit_sig_parameter_list(node, addnodes.desc_type_parameter)

    def depart_desc_type_parameter_list(self, node: Element) -> None:
        if self.orphan_tp_list:
            self.body.append('}' + CR + '{}' + CR + '{')
        else:
            self.body.append('}' + CR + '{')

    def _visit_sig_parameter(self, node: Element, parameter_macro: str) -> None:
        if self.is_first_param:
            self.is_first_param = False
        elif not self.multi_line_parameter_list and (not self.required_params_left):
            self.body.append(self.param_separator)
        if self.optional_param_level == 0:
            self.required_params_left -= 1
        else:
            self.params_left_at_level -= 1
        if not node.hasattr('noemph'):
            self.body.append(parameter_macro)

    def _depart_sig_parameter(self, node: Element) -> None:
        if not node.hasattr('noemph'):
            self.body.append('}')
        is_required = self.list_is_required_param[self.param_group_index]
        if self.multi_line_parameter_list:
            len_lirp = len(self.list_is_required_param)
            is_last_group = self.param_group_index + 1 == len_lirp
            next_is_required = not is_last_group and self.list_is_required_param[self.param_group_index + 1]
            opt_param_left_at_level = self.params_left_at_level > 0
            if opt_param_left_at_level or (is_required and (is_last_group or next_is_required)):
                self.body.append(self.param_separator)
        elif self.required_params_left:
            self.body.append(self.param_separator)
        if is_required:
            self.param_group_index += 1

    def visit_desc_parameter(self, node: Element) -> None:
        self._visit_sig_parameter(node, '\\sphinxparam{')

    def depart_desc_parameter(self, node: Element) -> None:
        self._depart_sig_parameter(node)

    def visit_desc_type_parameter(self, node: Element) -> None:
        self._visit_sig_parameter(node, '\\sphinxtypeparam{')

    def depart_desc_type_parameter(self, node: Element) -> None:
        self._depart_sig_parameter(node)

    def visit_desc_optional(self, node: Element) -> None:
        self.params_left_at_level = sum((isinstance(c, addnodes.desc_parameter) for c in node.children))
        self.optional_param_level += 1
        self.max_optional_param_level = self.optional_param_level
        if self.multi_line_parameter_list:
            if self.is_first_param:
                self.body.append('\\sphinxoptional{')
            elif self.required_params_left:
                self.body.append(self.param_separator)
                self.body.append('\\sphinxoptional{')
            else:
                self.body.append('\\sphinxoptional{')
                self.body.append(self.param_separator)
        else:
            self.body.append('\\sphinxoptional{')

    def depart_desc_optional(self, node: Element) -> None:
        self.optional_param_level -= 1
        if self.multi_line_parameter_list:
            if self.optional_param_level == self.max_optional_param_level - 1:
                self.body.append(self.param_separator)
        self.body.append('}')
        if self.optional_param_level == 0:
            self.param_group_index += 1

    def visit_desc_annotation(self, node: Element) -> None:
        self.body.append('\\sphinxbfcode{\\sphinxupquote{')

    def depart_desc_annotation(self, node: Element) -> None:
        self.body.append('}}')

    def visit_seealso(self, node: Element) -> None:
        self.body.append(BLANKLINE)
        self.body.append('\\begin{sphinxseealso}{%s:}' % admonitionlabels['seealso'] + CR)
        self.no_latex_floats += 1
        if self.table:
            self.table.has_problematic = True

    def depart_seealso(self, node: Element) -> None:
        self.body.append(BLANKLINE)
        self.body.append('\\end{sphinxseealso}')
        self.body.append(BLANKLINE)
        self.no_latex_floats -= 1

    def visit_rubric(self, node: nodes.rubric) -> None:
        if len(node) == 1 and node.astext() in ('Footnotes', _('Footnotes')):
            raise nodes.SkipNode
        tag = 'subsubsection'
        if 'heading-level' in node:
            level = node['heading-level']
            try:
                tag = self.sectionnames[self.top_sectionlevel - 1 + level]
            except Exception:
                logger.warning(__('unsupported rubric heading level: %s'), level, type='latex', location=node)
        self.body.append(f'\\{tag}*{{')
        self.context.append('}' + CR)
        self.in_title = 1

    def depart_rubric(self, node: nodes.rubric) -> None:
        self.in_title = 0
        self.body.append(self.context.pop())

    def visit_footnote(self, node: Element) -> None:
        self.in_footnote += 1
        label = cast(nodes.label, node[0])
        if self.in_parsed_literal:
            self.body.append('\\begin{footnote}[%s]' % label.astext())
        else:
            self.body.append('%' + CR)
            self.body.append('\\begin{footnote}[%s]' % label.astext())
        if 'referred' in node:
            pass
        self.body.append('\\sphinxAtStartFootnote' + CR)

    def depart_footnote(self, node: Element) -> None:
        if self.in_parsed_literal:
            self.body.append('\\end{footnote}')
        else:
            self.body.append('%' + CR)
            self.body.append('\\end{footnote}')
        self.in_footnote -= 1

    def visit_label(self, node: Element) -> None:
        raise nodes.SkipNode

    def visit_tabular_col_spec(self, node: Element) -> None:
        self.next_table_colspec = node['spec']
        raise nodes.SkipNode

    def visit_table(self, node: Element) -> None:
        if len(self.tables) == 1:
            assert self.table is not None
            if self.table.get_table_type() == 'longtable':
                raise UnsupportedError('%s:%s: longtable does not support nesting a table.' % (self.curfilestack[-1], node.line or ''))
            self.table.has_problematic = True
        elif len(self.tables) > 2:
            raise UnsupportedError('%s:%s: deeply nested tables are not implemented.' % (self.curfilestack[-1], node.line or ''))
        table = Table(node)
        self.tables.append(table)
        if table.colsep is None:
            table.colsep = '|' * ('booktabs' not in self.builder.config.latex_table_style and 'borderless' not in self.builder.config.latex_table_style)
        if self.next_table_colspec:
            table.colspec = '{%s}' % self.next_table_colspec + CR
            if '|' in table.colspec:
                table.styles.append('vlines')
                table.colsep = '|'
            else:
                table.styles.append('novlines')
                table.colsep = ''
            if 'colwidths-given' in node.get('classes', []):
                logger.info(__('both tabularcolumns and :widths: option are given. :widths: is ignored.'), location=node)
        self.next_table_colspec = None

    def depart_table(self, node: Element) -> None:
        assert self.table is not None
        labels = self.hypertarget_to(node)
        table_type = self.table.get_table_type()
        table = self.render(table_type + '.tex.jinja', {'table': self.table, 'labels': labels})
        self.body.append(BLANKLINE)
        self.body.append(table)
        self.body.append(CR)
        self.tables.pop()

    def visit_colspec(self, node: Element) -> None:
        assert self.table is not None
        self.table.colcount += 1
        if 'colwidth' in node:
            self.table.colwidths.append(node['colwidth'])
        if 'stub' in node:
            self.table.stubs.append(self.table.colcount - 1)

    def depart_colspec(self, node: Element) -> None:
        pass

    def visit_tgroup(self, node: Element) -> None:
        pass

    def depart_tgroup(self, node: Element) -> None:
        pass

    def visit_thead(self, node: Element) -> None:
        assert self.table is not None
        self.pushbody(self.table.header)

    def depart_thead(self, node: Element) -> None:
        if self.body and self.body[-1] == '\\sphinxhline':
            self.body.pop()
        self.popbody()

    def visit_tbody(self, node: Element) -> None:
        assert self.table is not None
        self.pushbody(self.table.body)

    def depart_tbody(self, node: Element) -> None:
        if self.body and self.body[-1] == '\\sphinxhline':
            self.body.pop()
        self.popbody()

    def visit_row(self, node: Element) -> None:
        assert self.table is not None
        self.table.col = 0
        _colsep = self.table.colsep
        while True:
            cell = self.table.cell(self.table.row, self.table.col)
            if cell is None:
                break
            self.table.col += cell.width
            if cell.col:
                self.body.append('&')
            if cell.width == 1:
                self.body.append('\\sphinxtablestrut{%d}' % cell.cell_id)
            else:
                self.body.append('\\multicolumn{%d}{%sl%s}{\\sphinxtablestrut{%d}}' % (cell.width, _colsep, _colsep, cell.cell_id))

    def depart_row(self, node: Element) -> None:
        assert self.table is not None
        self.body.append('\\\\' + CR)
        cells = [self.table.cell(self.table.row, i) for i in range(self.table.colcount)]
        underlined = [cell.row + cell.height == self.table.row + 1 for cell in cells]#type: ignore#type: ignore
        if all(underlined):
            self.body.append('\\sphinxhline')
        else:
            i = 0
            underlined.extend([False])
            if underlined[0] is False:
                i = 1
                while i < self.table.colcount and underlined[i] is False:
                    if cells[i - 1].cell_id != cells[i].cell_id:#type: ignore
                        self.body.append('\\sphinxvlinecrossing{%d}' % i)
                    i += 1
            while i < self.table.colcount:
                j = underlined[i:].index(False)
                self.body.append('\\sphinxcline{%d-%d}' % (i + 1, i + j))
                i += j
                i += 1
                while i < self.table.colcount and underlined[i] is False:
                    if cells[i - 1].cell_id != cells[i].cell_id:#type: ignore
                        self.body.append('\\sphinxvlinecrossing{%d}' % i)
                    i += 1
            self.body.append('\\sphinxfixclines{%d}' % self.table.colcount)
        self.table.row += 1

    def visit_entry(self, node: Element) -> None:
        assert self.table is not None
        if self.table.col > 0:
            self.body.append('&')
        self.table.add_cell(node.get('morerows', 0) + 1, node.get('morecols', 0) + 1)
        cell = self.table.cell()
        assert cell is not None
        context = ''
        _colsep = self.table.colsep
        if cell.width > 1:
            if self.config.latex_use_latex_multicolumn:
                if self.table.col == 0:
                    self.body.append('\\multicolumn{%d}{%sl%s}{%%' % (cell.width, _colsep, _colsep) + CR)
                else:
                    self.body.append('\\multicolumn{%d}{l%s}{%%' % (cell.width, _colsep) + CR)
                context = '}%' + CR
            else:
                self.body.append('\\sphinxstartmulticolumn{%d}%%' % cell.width + CR)
                context = '\\sphinxstopmulticolumn' + CR
        if cell.height > 1:
            self.body.append('\\sphinxmultirow{%d}{%d}{%%' % (cell.height, cell.cell_id) + CR)
            context = '}%' + CR + context
        if cell.width > 1 or cell.height > 1:
            self.body.append('\\begin{varwidth}[t]{\\sphinxcolwidth{%d}{%d}}' % (cell.width, self.table.colcount) + CR)
            context = '\\par' + CR + '\\vskip-\\baselineskip\\vbox{\\hbox{\\strut}}\\end{varwidth}%' + CR + context
            self.needs_linetrimming = 1
        if len(list(node.findall(nodes.paragraph))) >= 2:
            self.table.has_oldproblematic = True
        if isinstance(node.parent.parent, nodes.thead) or cell.col in self.table.stubs:
            if len(node) == 1 and isinstance(node[0], nodes.paragraph) and (node.astext() == ''):
                pass
            else:
                self.body.append('\\sphinxstyletheadfamily ')
        if self.needs_linetrimming:
            self.pushbody([])
        self.context.append(context)

    def depart_entry(self, node: Element) -> None:
        if self.needs_linetrimming:
            self.needs_linetrimming = 0
            body = self.popbody()
            while body and body[0] == CR:
                body.pop(0)
            self.body.extend(body)
        self.body.append(self.context.pop())
        assert self.table is not None
        cell = self.table.cell()
        assert cell is not None
        self.table.col += cell.width
        _colsep = self.table.colsep
        while True:
            nextcell = self.table.cell()
            if nextcell is None:
                break
            self.body.append('&')
            if nextcell.width == 1:
                self.body.append('\\sphinxtablestrut{%d}' % nextcell.cell_id)
            else:
                self.body.append('\\multicolumn{%d}{l%s}{\\sphinxtablestrut{%d}}' % (nextcell.width, _colsep, nextcell.cell_id))
            self.table.col += nextcell.width

    def visit_acks(self, node: Element) -> None:
        bullet_list = cast(nodes.bullet_list, node[0])
        list_items = cast(Iterable[nodes.list_item], bullet_list)
        self.body.append(BLANKLINE)
        self.body.append(', '.join((n.astext() for n in list_items)) + '.')
        self.body.append(BLANKLINE)
        raise nodes.SkipNode

    def visit_bullet_list(self, node: Element) -> None:
        if not self.compact_list:
            self.body.append('\\begin{itemize}' + CR)
        if self.table:
            self.table.has_problematic = True

    def depart_bullet_list(self, node: Element) -> None:
        if not self.compact_list:
            self.body.append('\\end{itemize}' + CR)

    def visit_enumerated_list(self, node: Element) -> None:

        def get_enumtype(node: Element) -> str:
            enumtype = node.get('enumtype', 'arabic')
            if 'alpha' in enumtype and node.get('start', 0) + len(node) > 26:
                enumtype = 'arabic'
            return enumtype

        def get_nested_level(node: Element) -> int:
            if node is None:
                return 0
            elif isinstance(node, nodes.enumerated_list):
                return get_nested_level(node.parent) + 1
            else:
                return get_nested_level(node.parent)
        enum = 'enum%s' % toRoman(get_nested_level(node)).lower()
        enumnext = 'enum%s' % toRoman(get_nested_level(node) + 1).lower()
        style = ENUMERATE_LIST_STYLE.get(get_enumtype(node))
        prefix = node.get('prefix', '')
        suffix = node.get('suffix', '.')
        self.body.append('\\begin{enumerate}' + CR)
        self.body.append('\\sphinxsetlistlabels{%s}{%s}{%s}{%s}{%s}%%' % (style, enum, enumnext, prefix, suffix) + CR)
        if 'start' in node:
            self.body.append('\\setcounter{%s}{%d}' % (enum, node['start'] - 1) + CR)
        if self.table:
            self.table.has_problematic = True

    def depart_enumerated_list(self, node: Element) -> None:
        self.body.append('\\end{enumerate}' + CR)

    def visit_list_item(self, node: Element) -> None:
        self.body.append('\\item {} ')

    def depart_list_item(self, node: Element) -> None:
        self.body.append(CR)

    def visit_definition_list(self, node: Element) -> None:
        self.body.append('\\begin{description}' + CR)
        if self.table:
            self.table.has_problematic = True

    def depart_definition_list(self, node: Element) -> None:
        self.body.append('\\end{description}' + CR)

    def visit_definition_list_item(self, node: Element) -> None:
        pass

    def depart_definition_list_item(self, node: Element) -> None:
        pass

    def visit_term(self, node: Element) -> None:
        self.in_term += 1
        ctx = ''
        if node.get('ids'):
            ctx = '\\phantomsection'
            for node_id in node['ids']:
                ctx += self.hypertarget(node_id, anchor=False)
        ctx += '}'
        self.body.append('\\sphinxlineitem{')
        self.context.append(ctx)

    def depart_term(self, node: Element) -> None:
        self.body.append(self.context.pop())
        self.in_term -= 1

    def visit_classifier(self, node: Element) -> None:
        self.body.append('{[}')

    def depart_classifier(self, node: Element) -> None:
        self.body.append('{]}')

    def visit_definition(self, node: Element) -> None:
        pass

    def depart_definition(self, node: Element) -> None:
        self.body.append(CR)

    def visit_field_list(self, node: Element) -> None:
        self.body.append('\\begin{quote}\\begin{description}' + CR)
        if self.table:
            self.table.has_problematic = True

    def depart_field_list(self, node: Element) -> None:
        self.body.append('\\end{description}\\end{quote}' + CR)

    def visit_field(self, node: Element) -> None:
        pass

    def depart_field(self, node: Element) -> None:
        pass
    visit_field_name = visit_term
    depart_field_name = depart_term
    visit_field_body = visit_definition
    depart_field_body = depart_definition

    def visit_paragraph(self, node: Element) -> None:
        index = node.parent.index(node)
        if index > 0 and isinstance(node.parent, nodes.compound) and (not isinstance(node.parent[index - 1], nodes.paragraph)) and (not isinstance(node.parent[index - 1], nodes.compound)):
            self.body.append('\\noindent' + CR)
        elif index == 1 and isinstance(node.parent, nodes.footnote | footnotetext):
            pass
        else:
            self.body.extend([CR, '\\sphinxAtStartPar' + CR])

    def depart_paragraph(self, node: Element) -> None:
        self.body.append(CR)

    def visit_centered(self, node: Element) -> None:
        self.body.append(CR + '\\begin{center}')
        if self.table:
            self.table.has_problematic = True

    def depart_centered(self, node: Element) -> None:
        self.body.append(CR + '\\end{center}')

    def visit_hlist(self, node: Element) -> None:
        self.compact_list += 1
        ncolumns = node['ncolumns']
        if self.compact_list > 1:
            self.body.append('\\setlength{\\multicolsep}{0pt}' + CR)
        self.body.append('\\begin{multicols}{' + ncolumns + '}\\raggedright' + CR)
        self.body.append('\\begin{itemize}\\setlength{\\itemsep}{0pt}\\setlength{\\parskip}{0pt}' + CR)
        if self.table:
            self.table.has_problematic = True

    def depart_hlist(self, node: Element) -> None:
        self.compact_list -= 1
        self.body.append('\\end{itemize}\\raggedcolumns\\end{multicols}' + CR)

    def visit_hlistcol(self, node: Element) -> None:
        pass

    def depart_hlistcol(self, node: Element) -> None:
        pass

    def latex_image_length(self, width_str: str, scale: int=100) -> str | None:
        try:
            return rstdim_to_latexdim(width_str, scale)
        except ValueError:
            logger.warning(__('dimension unit %s is invalid. Ignored.'), width_str)
            return None

    def is_inline(self, node: Element) -> bool:
        """Check whether a node represents an inline element."""
        return isinstance(node.parent, nodes.TextElement)

    def visit_image(self, node: Element) -> None:
        pre: list[str] = []
        post: list[str] = []
        include_graphics_options = []
        has_hyperlink = isinstance(node.parent, nodes.reference)
        if has_hyperlink:
            is_inline = self.is_inline(node.parent)
        else:
            is_inline = self.is_inline(node)
        if 'width' in node:
            if 'scale' in node:
                w = self.latex_image_length(node['width'], node['scale'])
            else:
                w = self.latex_image_length(node['width'])
            if w:
                include_graphics_options.append('width=%s' % w)
        if 'height' in node:
            if 'scale' in node:
                h = self.latex_image_length(node['height'], node['scale'])
            else:
                h = self.latex_image_length(node['height'])
            if h:
                include_graphics_options.append('height=%s' % h)
        if 'scale' in node:
            if not include_graphics_options:
                include_graphics_options.append('scale=%s' % (float(node['scale']) / 100.0))
        if 'align' in node:
            align_prepost = {(1, 'top'): ('', ''), (1, 'middle'): ('\\raisebox{-0.5\\height}{', '}'), (1, 'bottom'): ('\\raisebox{-\\height}{', '}'), (0, 'center'): ('{\\hspace*{\\fill}', '\\hspace*{\\fill}}'), (0, 'left'): ('{', '\\hspace*{\\fill}}'), (0, 'right'): ('{\\hspace*{\\fill}', '}')}
            try:
                pre.append(align_prepost[is_inline, node['align']][0])
                post.append(align_prepost[is_inline, node['align']][1])
            except KeyError:
                pass
        if self.in_parsed_literal:
            pre.append('{\\sphinxunactivateextrasandspace ')
            post.append('}')
        if not is_inline and (not has_hyperlink):
            pre.append(CR + '\\noindent')
            post.append(CR)
        pre.reverse()
        if node['uri'] in self.builder.images:
            uri = self.builder.images[node['uri']]
        else:
            if self.ignore_missing_images:
                return
            uri = node['uri']
        if uri.find('://') != -1:
            return
        self.body.extend(pre)
        options = ''
        if include_graphics_options:
            options = '[%s]' % ','.join(include_graphics_options)
        (base, ext) = path.splitext(uri)
        if self.in_title and base:
            cmd = f'\\lowercase{{\\sphinxincludegraphics{options}}}{{{{{base}}}{ext}}}'
        else:
            cmd = f'\\sphinxincludegraphics{options}{{{{{base}}}{ext}}}'
        if '#' in base:
            cmd = '{\\catcode`\\#=12' + cmd + '}'
        self.body.append(cmd)
        self.body.extend(post)

    def depart_image(self, node: Element) -> None:
        pass

    def visit_figure(self, node: Element) -> None:
        align = self.elements['figure_align']
        if self.no_latex_floats:
            align = 'H'
        if self.table:
            self.body.append(BLANKLINE)
            if 'width' in node:
                length = self.latex_image_length(node['width'])
                if length:
                    self.body.append('\\begin{sphinxfigure-in-table}[%s]' % length + CR)
                    self.body.append('\\centering' + CR)
            else:
                self.body.append('\\begin{sphinxfigure-in-table}' + CR)
                self.body.append('\\centering' + CR)
            if any((isinstance(child, nodes.caption) for child in node)):
                self.body.append('\\capstart')
            self.context.append('\\end{sphinxfigure-in-table}\\relax' + CR)
        elif node.get('align', '') in ('left', 'right'):
            length = None
            if 'width' in node:
                length = self.latex_image_length(node['width'])
            elif isinstance(node[0], nodes.image) and 'width' in node[0]:
                length = self.latex_image_length(node[0]['width'])
            self.body.append(BLANKLINE)
            self.body.append('\\begin{wrapfigure}{%s}{%s}' % ('r' if node['align'] == 'right' else 'l', length or '0pt') + CR)
            self.body.append('\\centering')
            self.context.append('\\end{wrapfigure}' + BLANKLINE + '\\mbox{}\\par\\vskip-\\dimexpr\\baselineskip+\\parskip\\relax' + CR)
        elif self.in_minipage:
            self.body.append(CR + '\\begin{center}')
            self.context.append('\\end{center}' + CR)
        else:
            self.body.append(CR + '\\begin{figure}[%s]' % align + CR)
            self.body.append('\\centering' + CR)
            if any((isinstance(child, nodes.caption) for child in node)):
                self.body.append('\\capstart' + CR)
            self.context.append('\\end{figure}' + CR)

    def depart_figure(self, node: Element) -> None:
        self.body.append(self.context.pop())

    def visit_caption(self, node: Element) -> None:
        self.in_caption += 1
        if isinstance(node.parent, captioned_literal_block):
            self.body.append('\\sphinxSetupCaptionForVerbatim{')
        elif self.in_minipage and isinstance(node.parent, nodes.figure):
            self.body.append('\\captionof{figure}{')
        elif self.table and node.parent.tagname == 'figure':
            self.body.append('\\sphinxfigcaption{')
        else:
            self.body.append('\\caption{')

    def depart_caption(self, node: Element) -> None:
        self.body.append('}')
        if isinstance(node.parent, nodes.figure):
            labels = self.hypertarget_to(node.parent)
            self.body.append(labels)
        self.in_caption -= 1

    def visit_legend(self, node: Element) -> None:
        self.body.append(CR + '\\begin{sphinxlegend}')

    def depart_legend(self, node: Element) -> None:
        self.body.append('\\end{sphinxlegend}' + CR)

    def visit_admonition(self, node: Element) -> None:
        self.body.append(CR + '\\begin{sphinxadmonition}{note}')
        self.no_latex_floats += 1
        if self.table:
            self.table.has_problematic = True

    def depart_admonition(self, node: Element) -> None:
        self.body.append('\\end{sphinxadmonition}' + CR)
        self.no_latex_floats -= 1

    def _visit_named_admonition(self, node: Element) -> None:
        label = admonitionlabels[node.tagname]
        self.body.append(CR + '\\begin{sphinxadmonition}{%s}{%s:}' % (node.tagname, label))
        self.no_latex_floats += 1
        if self.table:
            self.table.has_problematic = True

    def _depart_named_admonition(self, node: Element) -> None:
        self.body.append('\\end{sphinxadmonition}' + CR)
        self.no_latex_floats -= 1
    visit_attention = _visit_named_admonition
    depart_attention = _depart_named_admonition
    visit_caution = _visit_named_admonition
    depart_caution = _depart_named_admonition
    visit_danger = _visit_named_admonition
    depart_danger = _depart_named_admonition
    visit_error = _visit_named_admonition
    depart_error = _depart_named_admonition
    visit_hint = _visit_named_admonition
    depart_hint = _depart_named_admonition
    visit_important = _visit_named_admonition
    depart_important = _depart_named_admonition
    visit_note = _visit_named_admonition
    depart_note = _depart_named_admonition
    visit_tip = _visit_named_admonition
    depart_tip = _depart_named_admonition
    visit_warning = _visit_named_admonition
    depart_warning = _depart_named_admonition

    def visit_versionmodified(self, node: Element) -> None:
        pass

    def depart_versionmodified(self, node: Element) -> None:
        pass

    def visit_target(self, node: Element) -> None:

        def add_target(id: str) -> None:
            if id.startswith('index-'):
                return
            if id.startswith('equation-'):
                return
            index = node.parent.index(node)
            if index > 0 and isinstance(node.parent[index - 1], nodes.paragraph):
                self.body.append(CR)
            anchor = not self.in_title
            self.body.append(self.hypertarget(id, anchor=anchor))
        next_node: Node = node
        while isinstance(next_node, nodes.target):
            next_node = next_node.next_node(ascend=True)
        domain = self.builder.env.domains.standard_domain
        if isinstance(next_node, HYPERLINK_SUPPORT_NODES):
            return
        if domain.get_enumerable_node_type(next_node) and domain.get_numfig_title(next_node):
            return
        if 'refuri' in node:
            return
        if 'anonymous' in node:
            return
        if node.get('refid'):
            prev_node = get_prev_node(node)
            if isinstance(prev_node, nodes.reference) and node['refid'] == prev_node['refid']:
                pass
            else:
                add_target(node['refid'])
        if node.get('ismod', False):

            def has_dup_label(sib: Node | None) -> bool:
                return isinstance(sib, nodes.target) and sib.get('refid') in node['ids']
            prev = get_prev_node(node)
            if has_dup_label(prev):
                ids = node['ids'][:]
                while has_dup_label(prev):
                    ids.remove(prev['refid'])
                    prev = get_prev_node(prev)
            else:
                ids = iter(node['ids'])
        else:
            ids = iter(node['ids'])
        for id in ids:
            add_target(id)

    def depart_target(self, node: Element) -> None:
        pass

    def visit_attribution(self, node: Element) -> None:
        self.body.append(CR + '\\begin{flushright}' + CR)
        self.body.append('---')

    def depart_attribution(self, node: Element) -> None:
        self.body.append(CR + '\\end{flushright}' + CR)

    def visit_index(self, node: Element) -> None:

        def escape(value: str) -> str:
            value = self.encode(value)
            value = value.replace('\\{', '\\sphinxleftcurlybrace{}')
            value = value.replace('\\}', '\\sphinxrightcurlybrace{}')
            value = value.replace('"', '""')
            value = value.replace('@', '"@')
            value = value.replace('!', '"!')
            value = value.replace('|', '\\textbar{}')
            return value

        def style(string: str) -> str:
            match = EXTRA_RE.match(string)
            if match:
                return match.expand('\\\\spxentry{\\1}\\\\spxextra{\\2}')
            else:
                return '\\spxentry{%s}' % string
        if not node.get('inline', True):
            self.body.append(CR)
        entries = node['entries']
        for (type, string, _tid, ismain, _key) in entries:
            m = ''
            if ismain:
                m = '|spxpagem'
            try:
                parts = tuple(map(escape, split_index_msg(type, string)))
                styled = tuple(map(style, parts))
                if type == 'single':
                    try:
                        (p1, p2) = parts
                        (P1, P2) = styled
                        self.body.append(f'\\index{{{p1}@{P1}!{p2}@{P2}{m}}}')
                    except ValueError:
                        (p,) = parts
                        (P,) = styled
                        self.body.append(f'\\index{{{p}@{P}{m}}}')
                elif type == 'pair':
                    (p1, p2) = parts
                    (P1, P2) = styled
                    self.body.append(f'\\index{{{p1}@{P1}!{p2}@{P2}{m}}}\\index{{{p2}@{P2}!{p1}@{P1}{m}}}')
                elif type == 'triple':
                    (p1, p2, p3) = parts
                    (P1, P2, P3) = styled
                    self.body.append(f'\\index{{{p1}@{P1}!{p2} {p3}@{P2} {P3}{m}}}\\index{{{p2}@{P2}!{p3}, {p1}@{P3}, {P1}{m}}}\\index{{{p3}@{P3}!{p1} {p2}@{P1} {P2}{m}}}')
                elif type in {'see', 'seealso'}:
                    (p1, p2) = parts
                    (P1, _P2) = styled
                    self.body.append(f'\\index{{{p1}@{P1}|see{{{p2}}}}}')
                else:
                    logger.warning(__('unknown index entry type %s found'), type)
            except ValueError as err:
                logger.warning(str(err))
        if not node.get('inline', True):
            self.body.append('\\ignorespaces ')
        raise nodes.SkipNode

    def visit_raw(self, node: Element) -> None:
        if not self.is_inline(node):
            self.body.append(CR)
        if 'latex' in node.get('format', '').split():
            self.body.append(node.astext())
        if not self.is_inline(node):
            self.body.append(CR)
        raise nodes.SkipNode

    def visit_reference(self, node: Element) -> None:
        if not self.in_title:
            for id in node.get('ids'):
                anchor = not self.in_caption
                self.body += self.hypertarget(id, anchor=anchor)
        if not self.is_inline(node):
            self.body.append(CR)
        uri = node.get('refuri', '')
        if not uri and node.get('refid'):
            uri = '%' + self.curfilestack[-1] + '#' + node['refid']
        if self.in_title or not uri:
            self.context.append('')
        elif uri.startswith('#'):
            id = self.curfilestack[-1] + ':' + uri[1:]
            self.body.append(self.hyperlink(id))
            self.body.append('\\sphinxsamedocref{')
            if self.config.latex_show_pagerefs and (not self.in_production_list):
                self.context.append('}}} (%s)' % self.hyperpageref(id))
            else:
                self.context.append('}}}')
        elif uri.startswith('%'):
            hashindex = uri.find('#')
            if hashindex == -1:
                id = uri[1:] + '::doc'
            else:
                id = uri[1:].replace('#', ':')
            self.body.append(self.hyperlink(id))
            if len(node) and isinstance(node[0], nodes.Element) and ('std-term' in node[0].get('classes', [])):
                self.context.append('}}}')
                self.body.append('\\sphinxtermref{')
            else:
                self.body.append('\\sphinxcrossref{')
                if self.config.latex_show_pagerefs and (not self.in_production_list):
                    self.context.append('}}} (%s)' % self.hyperpageref(id))
                else:
                    self.context.append('}}}')
        elif len(node) == 1 and uri == node[0]:
            if node.get('nolinkurl'):
                self.body.append('\\sphinxnolinkurl{%s}' % self.encode_uri(uri))
            else:
                self.body.append('\\sphinxurl{%s}' % self.encode_uri(uri))
            raise nodes.SkipNode
        else:
            self.body.append('\\sphinxhref{%s}{' % self.encode_uri(uri))
            self.context.append('}')

    def depart_reference(self, node: Element) -> None:
        self.body.append(self.context.pop())
        if not self.is_inline(node):
            self.body.append(CR)

    def visit_number_reference(self, node: Element) -> None:
        if node.get('refid'):
            id = self.curfilestack[-1] + ':' + node['refid']
        else:
            id = node.get('refuri', '')[1:].replace('#', ':')
        title = self.escape(node.get('title', '%s')).replace('\\%s', '%s')
        if '\\{name\\}' in title or '\\{number\\}' in title:
            title = title.replace('\\{name\\}', '{name}').replace('\\{number\\}', '{number}')
            text = escape_abbr(title).format(name='\\nameref{%s}' % self.idescape(id), number='\\ref{%s}' % self.idescape(id))
        else:
            text = escape_abbr(title) % ('\\ref{%s}' % self.idescape(id))
        hyperref = f'\\hyperref[{self.idescape(id)}]{{{text}}}'
        self.body.append(hyperref)
        raise nodes.SkipNode

    def visit_download_reference(self, node: Element) -> None:
        pass

    def depart_download_reference(self, node: Element) -> None:
        pass

    def visit_pending_xref(self, node: Element) -> None:
        pass

    def depart_pending_xref(self, node: Element) -> None:
        pass

    def visit_emphasis(self, node: Element) -> None:
        self.body.append('\\sphinxstyleemphasis{')

    def depart_emphasis(self, node: Element) -> None:
        self.body.append('}')

    def visit_literal_emphasis(self, node: Element) -> None:
        self.body.append('\\sphinxstyleliteralemphasis{\\sphinxupquote{')

    def depart_literal_emphasis(self, node: Element) -> None:
        self.body.append('}}')

    def visit_strong(self, node: Element) -> None:
        self.body.append('\\sphinxstylestrong{')

    def depart_strong(self, node: Element) -> None:
        self.body.append('}')

    def visit_literal_strong(self, node: Element) -> None:
        self.body.append('\\sphinxstyleliteralstrong{\\sphinxupquote{')

    def depart_literal_strong(self, node: Element) -> None:
        self.body.append('}}')

    def visit_abbreviation(self, node: Element) -> None:
        abbr = node.astext()
        self.body.append('\\sphinxstyleabbreviation{')
        if node.hasattr('explanation') and abbr not in self.handled_abbrs:
            self.context.append('} (%s)' % self.encode(node['explanation']))
            self.handled_abbrs.add(abbr)
        else:
            self.context.append('}')

    def depart_abbreviation(self, node: Element) -> None:
        self.body.append(self.context.pop())

    def visit_manpage(self, node: Element) -> None:
        return self.visit_literal_emphasis(node)

    def depart_manpage(self, node: Element) -> None:
        return self.depart_literal_emphasis(node)

    def visit_title_reference(self, node: Element) -> None:
        self.body.append('\\sphinxtitleref{')

    def depart_title_reference(self, node: Element) -> None:
        self.body.append('}')

    def visit_thebibliography(self, node: Element) -> None:
        citations = cast(Iterable[nodes.citation], node)
        labels = (cast(nodes.label, citation[0]) for citation in citations)
        longest_label = max((label.astext() for label in labels), key=len)
        if len(longest_label) > MAX_CITATION_LABEL_LENGTH:
            longest_label = longest_label[:MAX_CITATION_LABEL_LENGTH]
        self.body.append(CR + '\\begin{sphinxthebibliography}{%s}' % self.encode(longest_label) + CR)

    def depart_thebibliography(self, node: Element) -> None:
        self.body.append('\\end{sphinxthebibliography}' + CR)

    def visit_citation(self, node: Element) -> None:
        label = cast(nodes.label, node[0])
        self.body.append(f"\\bibitem[{self.encode(label.astext())}]{{{node['docname']}:{node['ids'][0]}}}")

    def depart_citation(self, node: Element) -> None:
        pass

    def visit_citation_reference(self, node: Element) -> None:
        if self.in_title:
            pass
        else:
            self.body.append(f"\\sphinxcite{{{node['docname']}:{node['refname']}}}")
            raise nodes.SkipNode

    def depart_citation_reference(self, node: Element) -> None:
        pass

    def visit_literal(self, node: Element) -> None:
        if self.in_title:
            self.body.append('\\sphinxstyleliteralintitle{\\sphinxupquote{')
            return
        elif 'kbd' in node['classes']:
            self.body.append('\\sphinxkeyboard{\\sphinxupquote{')
            return
        lang = node.get('language', None)
        if 'code' not in node['classes'] or not lang:
            self.body.append('\\sphinxcode{\\sphinxupquote{')
            return
        opts = self.config.highlight_options.get(lang, {})
        hlcode = self.highlighter.highlight_block(node.astext(), lang, opts=opts, location=node, nowrap=True)
        self.body.append('\\sphinxcode{\\sphinxupquote{%' + CR + hlcode.rstrip() + '%' + CR + '}}')
        raise nodes.SkipNode

    def depart_literal(self, node: Element) -> None:
        self.body.append('}}')

    def visit_footnote_reference(self, node: Element) -> None:
        raise nodes.SkipNode

    def visit_footnotemark(self, node: Element) -> None:
        self.body.append('\\sphinxfootnotemark[')

    def depart_footnotemark(self, node: Element) -> None:
        self.body.append(']')

    def visit_footnotetext(self, node: Element) -> None:
        label = cast(nodes.label, node[0])
        self.body.append('%' + CR)
        self.body.append('\\begin{footnotetext}[%s]' % label.astext())
        self.body.append('\\sphinxAtStartFootnote' + CR)

    def depart_footnotetext(self, node: Element) -> None:
        self.body.append('%' + CR)
        self.body.append('\\end{footnotetext}\\ignorespaces ')

    def visit_captioned_literal_block(self, node: Element) -> None:
        pass

    def depart_captioned_literal_block(self, node: Element) -> None:
        pass

    def visit_literal_block(self, node: Element) -> None:
        if node.rawsource != node.astext():
            self.in_parsed_literal += 1
            self.body.append('\\begin{sphinxalltt}' + CR)
        else:
            labels = self.hypertarget_to(node)
            if isinstance(node.parent, captioned_literal_block):
                labels += self.hypertarget_to(node.parent)
            if labels and (not self.in_footnote):
                self.body.append(CR + '\\def\\sphinxLiteralBlockLabel{' + labels + '}')
            lang = node.get('language', 'default')
            linenos = node.get('linenos', False)
            highlight_args = node.get('highlight_args', {})
            highlight_args['force'] = node.get('force', False)
            opts = self.config.highlight_options.get(lang, {})
            hlcode = self.highlighter.highlight_block(node.rawsource, lang, opts=opts, linenos=linenos, location=node, **highlight_args)
            if self.in_footnote:
                self.body.append(CR + '\\sphinxSetupCodeBlockInFootnote')
                hlcode = hlcode.replace('\\begin{Verbatim}', '\\begin{sphinxVerbatim}')
            elif self.table:
                self.table.has_problematic = True
                self.table.has_verbatim = True
                hlcode = hlcode.replace('\\begin{Verbatim}', '\\begin{sphinxVerbatimintable}')
            else:
                hlcode = hlcode.replace('\\begin{Verbatim}', '\\begin{sphinxVerbatim}')
            hlcode = hlcode.rstrip()[:-14]
            if self.table and (not self.in_footnote):
                hlcode += '\\end{sphinxVerbatimintable}'
            else:
                hlcode += '\\end{sphinxVerbatim}'
            hllines = str(highlight_args.get('hl_lines', []))[1:-1]
            if hllines:
                self.body.append(CR + '\\fvset{hllines={, %s,}}%%' % hllines)
            self.body.append(CR + hlcode + CR)
            if hllines:
                self.body.append('\\sphinxresetverbatimhllines' + CR)
            raise nodes.SkipNode

    def depart_literal_block(self, node: Element) -> None:
        self.body.append(CR + '\\end{sphinxalltt}' + CR)
        self.in_parsed_literal -= 1
    visit_doctest_block = visit_literal_block
    depart_doctest_block = depart_literal_block

    def visit_line(self, node: Element) -> None:
        self.body.append('\\item[] ')

    def depart_line(self, node: Element) -> None:
        self.body.append(CR)

    def visit_line_block(self, node: Element) -> None:
        if isinstance(node.parent, nodes.line_block):
            self.body.append('\\item[]' + CR)
            self.body.append('\\begin{DUlineblock}{\\DUlineblockindent}' + CR)
        else:
            self.body.append(CR + '\\begin{DUlineblock}{0em}' + CR)
        if self.table:
            self.table.has_problematic = True

    def depart_line_block(self, node: Element) -> None:
        self.body.append('\\end{DUlineblock}' + CR)

    def visit_block_quote(self, node: Element) -> None:
        done = 0
        if len(node.children) == 1:
            child = node.children[0]
            if isinstance(child, nodes.bullet_list | nodes.enumerated_list):
                done = 1
        if not done:
            self.body.append('\\begin{quote}' + CR)
            if self.table:
                self.table.has_problematic = True

    def depart_block_quote(self, node: Element) -> None:
        done = 0
        if len(node.children) == 1:
            child = node.children[0]
            if isinstance(child, nodes.bullet_list | nodes.enumerated_list):
                done = 1
        if not done:
            self.body.append('\\end{quote}' + CR)

    def visit_option(self, node: Element) -> None:
        if self.context[-1]:
            self.body.append(', ')

    def depart_option(self, node: Element) -> None:
        self.context[-1] += 1

    def visit_option_argument(self, node: Element) -> None:
        """The delimiter between an option and its argument."""
        self.body.append(node.get('delimiter', ' '))

    def depart_option_argument(self, node: Element) -> None:
        pass

    def visit_option_group(self, node: Element) -> None:
        self.body.append('\\item [')
        self.context.append(0)

    def depart_option_group(self, node: Element) -> None:
        self.context.pop()
        self.body.append('] ')

    def visit_option_list(self, node: Element) -> None:
        self.body.append('\\begin{optionlist}{3cm}' + CR)
        if self.table:
            self.table.has_problematic = True

    def depart_option_list(self, node: Element) -> None:
        self.body.append('\\end{optionlist}' + CR)

    def visit_option_list_item(self, node: Element) -> None:
        pass

    def depart_option_list_item(self, node: Element) -> None:
        pass

    def visit_option_string(self, node: Element) -> None:
        ostring = node.astext()
        self.body.append(self.encode(ostring))
        raise nodes.SkipNode

    def visit_description(self, node: Element) -> None:
        self.body.append(' ')

    def depart_description(self, node: Element) -> None:
        pass

    def visit_superscript(self, node: Element) -> None:
        self.body.append('$^{\\text{')

    def depart_superscript(self, node: Element) -> None:
        self.body.append('}}$')

    def visit_subscript(self, node: Element) -> None:
        self.body.append('$_{\\text{')

    def depart_subscript(self, node: Element) -> None:
        self.body.append('}}$')

    def visit_inline(self, node: Element) -> None:
        classes = node.get('classes', [])
        if classes == ['menuselection']:
            self.body.append('\\sphinxmenuselection{')
            self.context.append('}')
        elif classes == ['guilabel']:
            self.body.append('\\sphinxguilabel{')
            self.context.append('}')
        elif classes == ['accelerator']:
            self.body.append('\\sphinxaccelerator{')
            self.context.append('}')
        elif classes and (not self.in_title):
            self.body.append('\\DUrole{' + '}{\\DUrole{'.join(classes) + '}{')
            self.context.append('}' * len(classes))
        else:
            self.context.append('')

    def depart_inline(self, node: Element) -> None:
        self.body.append(self.context.pop())

    def visit_generated(self, node: Element) -> None:
        pass

    def depart_generated(self, node: Element) -> None:
        pass

    def visit_compound(self, node: Element) -> None:
        pass

    def depart_compound(self, node: Element) -> None:
        pass

    def visit_container(self, node: Element) -> None:
        classes = node.get('classes', [])
        for c in classes:
            self.body.append('\n\\begin{sphinxuseclass}{%s}' % c)

    def depart_container(self, node: Element) -> None:
        classes = node.get('classes', [])
        for _c in classes:
            self.body.append('\n\\end{sphinxuseclass}')

    def visit_decoration(self, node: Element) -> None:
        pass

    def depart_decoration(self, node: Element) -> None:
        pass

    def visit_header(self, node: Element) -> None:
        raise nodes.SkipNode

    def visit_footer(self, node: Element) -> None:
        raise nodes.SkipNode

    def visit_docinfo(self, node: Element) -> None:
        raise nodes.SkipNode

    def encode(self, text: str) -> str:
        text = self.escape(text)
        if self.literal_whitespace:
            text = text.replace(CR, '~\\\\' + CR).replace(' ', '~')
        return text

    def encode_uri(self, text: str) -> str:
        return self.encode(text).replace('\\textasciitilde{}', '~').replace('\\sphinxhyphen{}', '-').replace('\\textquotesingle{}', "'")

    def visit_Text(self, node: Text) -> None:
        text = self.encode(node.astext())
        self.body.append(text)

    def depart_Text(self, node: Text) -> None:
        pass

    def visit_comment(self, node: Element) -> None:
        raise nodes.SkipNode

    def visit_meta(self, node: Element) -> None:
        raise nodes.SkipNode

    def visit_system_message(self, node: Element) -> None:
        pass

    def depart_system_message(self, node: Element) -> None:
        self.body.append(CR)

    def visit_math(self, node: Element) -> None:
        if self.in_title:
            self.body.append('\\protect\\(%s\\protect\\)' % node.astext())
        else:
            self.body.append('\\(%s\\)' % node.astext())
        raise nodes.SkipNode

    def visit_math_block(self, node: Element) -> None:
        if node.get('label'):
            label = f"equation:{node['docname']}:{node['label']}"
        else:
            label = None
        if node.get('nowrap'):
            if label:
                self.body.append('\\label{%s}' % label)
            self.body.append(node.astext())
        else:
            from sphinx.util.math import wrap_displaymath
            self.body.append(wrap_displaymath(node.astext(), label, self.config.math_number_all))
        raise nodes.SkipNode

    def visit_math_reference(self, node: Element) -> None:
        label = f"equation:{node['docname']}:{node['target']}"
        eqref_format = self.config.math_eqref_format
        if eqref_format:
            try:
                ref = '\\ref{%s}' % label
                self.body.append(eqref_format.format(number=ref))
            except KeyError as exc:
                logger.warning(__('Invalid math_eqref_format: %r'), exc, location=node)
                self.body.append('\\eqref{%s}' % label)
        else:
            self.body.append('\\eqref{%s}' % label)

    def depart_math_reference(self, node: Element) -> None:
        pass
from sphinx.builders.latex.nodes import HYPERLINK_SUPPORT_NODES, captioned_literal_block, footnotetext