"""The Sphinx documentation toolchain."""
__version__ = '8.1.3'
__display_version__ = __version__
import os
import warnings
if 'PYTHONWARNINGS' not in os.environ:
    from sphinx.deprecation import RemovedInNextVersionWarning
    warnings.filterwarnings('default', category=RemovedInNextVersionWarning)
warnings.filterwarnings('ignore', 'The frontend.Option class .*', DeprecationWarning, module='docutils.frontend')
version_info = (8, 1, 3, 'final', 0)
package_dir = os.path.abspath(os.path.dirname(__file__))
_in_development = False
if _in_development:
    import subprocess
    try:
        if (ret := subprocess.run(['git', 'rev-parse', '--short', 'HEAD'], cwd=package_dir, capture_output=True, check=False, encoding='ascii', errors='surrogateescape').stdout):
            __display_version__ += '+/' + ret.strip()
        del ret
    finally:
        del subprocess
del _in_development