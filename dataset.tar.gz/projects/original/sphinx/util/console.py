"""Format colored console output."""
from __future__ import annotations
import os
import re
import shutil
import sys
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from typing import Final

    def reset(text: str) -> str:
        ...

    def bold(text: str) -> str:
        ...

    def faint(text: str) -> str:
        ...

    def standout(text: str) -> str:
        ...

    def underline(text: str) -> str:
        ...

    def blink(text: str) -> str:
        ...

    def black(text: str) -> str:
        ...

    def white(text: str) -> str:
        ...

    def red(text: str) -> str:
        ...

    def green(text: str) -> str:
        ...

    def yellow(text: str) -> str:
        ...

    def blue(text: str) -> str:
        ...

    def fuchsia(text: str) -> str:
        ...

    def teal(text: str) -> str:
        ...

    def darkgray(text: str) -> str:
        ...

    def lightgray(text: str) -> str:
        ...

    def darkred(text: str) -> str:
        ...

    def darkgreen(text: str) -> str:
        ...

    def brown(text: str) -> str:
        ...

    def darkblue(text: str) -> str:
        ...

    def purple(text: str) -> str:
        ...

    def turquoise(text: str) -> str:
        ...
try:
    import colorama
    COLORAMA_AVAILABLE = True
except ImportError:
    COLORAMA_AVAILABLE = False
_CSI: Final[str] = re.escape('\x1b[')
_ansi_color_re: Final[re.Pattern[str]] = re.compile('\\x1b\\[(?:\\d+;){0,2}\\d*m')
_ansi_re: Final[re.Pattern[str]] = re.compile(_CSI + "\n    (?:\n      (?:\\d+;){0,2}\\d*m     # ANSI color code    ('m' is equivalent to '0m')\n    |\n      [012]?K               # ANSI Erase in Line ('K' is equivalent to '0K')\n    )", re.VERBOSE | re.ASCII)
'Pattern matching ANSI CSI colors (SGR) and erase line (EL) sequences.\n\nSee :func:`strip_escape_sequences` for details.\n'
codes: dict[str, str] = {}

def terminal_safe(s: str) -> str:
    """Safely encode a string for printing to the terminal."""
    return s.encode('ascii', 'backslashreplace').decode('ascii')

def get_terminal_width() -> int:
    """Return the width of the terminal in columns."""
    return shutil.get_terminal_size().columns - 1
_tw: int = get_terminal_width()

def term_width_line(text: str) -> str:
    if not codes:
        return text + '\n'
    else:
        return text.ljust(_tw + len(text) - len(strip_escape_sequences(text))) + '\r'

def color_terminal() -> bool:
    if 'NO_COLOR' in os.environ:
        return False
    if sys.platform == 'win32' and COLORAMA_AVAILABLE:
        colorama.just_fix_windows_console()
        return True
    if 'FORCE_COLOR' in os.environ:
        return True
    if not hasattr(sys.stdout, 'isatty'):
        return False
    if not sys.stdout.isatty():
        return False
    if 'COLORTERM' in os.environ:
        return True
    term = os.environ.get('TERM', 'dumb').lower()
    return term in ('xterm', 'linux') or 'color' in term

def nocolor() -> None:
    if sys.platform == 'win32' and COLORAMA_AVAILABLE:
        colorama.deinit()
    codes.clear()

def coloron() -> None:
    codes.update(_orig_codes)

def colorize(name: str, text: str, input_mode: bool=False) -> str:

    def escseq(name: str) -> str:
        escape = codes.get(name, '')
        if input_mode and escape and (sys.platform != 'win32'):
            return '\x01' + escape + '\x02'
        else:
            return escape
    return escseq(name) + text + escseq('reset')

def strip_colors(s: str) -> str:
    """Remove the ANSI color codes in a string *s*.

    .. caution::

       This function is not meant to be used in production and should only
       be used for testing Sphinx's output messages.

    .. seealso:: :func:`strip_escape_sequences`
    """
    return _ansi_color_re.sub('', s)

def strip_escape_sequences(text: str, /) -> str:
    """Remove the ANSI CSI colors and "erase in line" sequences.

    Other `escape sequences `__ (e.g., VT100-specific functions) are not
    supported and only control sequences *natively* known to Sphinx (i.e.,
    colors declared in this module and "erase entire line" (``'\\x1b[2K'``))
    are eliminated by this function.

    .. caution::

       This function is not meant to be used in production and should only
       be used for testing Sphinx's output messages that were not tempered
       with by third-party extensions.

    .. versionadded:: 7.3

       This function is added as an *experimental* feature.

    __ https://en.wikipedia.org/wiki/ANSI_escape_code
    """
    return _ansi_re.sub('', text)

def create_color_func(name: str) -> None:

    def inner(text: str) -> str:
        return colorize(name, text)
    globals()[name] = inner
_attrs = {'reset': '39;49;00m', 'bold': '01m', 'faint': '02m', 'standout': '03m', 'underline': '04m', 'blink': '05m'}
for (__name, __value) in _attrs.items():
    codes[__name] = '\x1b[' + __value
_colors = [('black', 'darkgray'), ('darkred', 'red'), ('darkgreen', 'green'), ('brown', 'yellow'), ('darkblue', 'blue'), ('purple', 'fuchsia'), ('turquoise', 'teal'), ('lightgray', 'white')]
for (__i, (__dark, __light)) in enumerate(_colors, 30):
    codes[__dark] = '\x1b[%im' % __i
    codes[__light] = '\x1b[%im' % (__i + 60)
_orig_codes = codes.copy()
for _name in codes:
    create_color_func(_name)