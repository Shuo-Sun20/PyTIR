from __future__ import annotations
import argparse
import os
import sys
if sys.platform == 'win32':

    def _enable() -> None:
        from ctypes import POINTER#type: ignore
        from ctypes import windll#type: ignore
        from ctypes import WinError#type: ignore
        from ctypes import WINFUNCTYPE#type: ignore
        from ctypes.wintypes import BOOL#type: ignore
        from ctypes.wintypes import DWORD#type: ignore
        from ctypes.wintypes import HANDLE#type: ignore
        STD_ERROR_HANDLE = -12
        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 4

        def bool_errcheck(result, func, args):
            if not result:
                raise WinError()
            return args
        GetStdHandle = WINFUNCTYPE(HANDLE, DWORD)(('GetStdHandle', windll.kernel32), ((1, 'nStdHandle'),))
        GetConsoleMode = WINFUNCTYPE(BOOL, HANDLE, POINTER(DWORD))(('GetConsoleMode', windll.kernel32), ((1, 'hConsoleHandle'), (2, 'lpMode')))
        GetConsoleMode.errcheck = bool_errcheck
        SetConsoleMode = WINFUNCTYPE(BOOL, HANDLE, DWORD)(('SetConsoleMode', windll.kernel32), ((1, 'hConsoleHandle'), (1, 'dwMode')))
        SetConsoleMode.errcheck = bool_errcheck
        stderr = GetStdHandle(STD_ERROR_HANDLE)
        flags = GetConsoleMode(stderr)
        SetConsoleMode(stderr, flags | ENABLE_VIRTUAL_TERMINAL_PROCESSING)
    try:
        _enable()
    except OSError:
        terminal_supports_color = False
    else:
        terminal_supports_color = True
else:
    terminal_supports_color = True
RED = '\x1b[41m'
GREEN = '\x1b[42m'
YELLOW = '\x1b[43;30m'
TURQUOISE = '\x1b[46;30m'
SUBTLE = '\x1b[2m'
NORMAL = '\x1b[m'

def format_color(text: str, color: str, use_color_setting: bool) -> str:
    """Format text with color.

    Args:
        text - Text to be formatted with color if `use_color`
        color - The color start string
        use_color_setting - Whether or not to color
    """
    if use_color_setting:
        return f'{color}{text}{NORMAL}'
    else:
        return text
COLOR_CHOICES = ('auto', 'always', 'never')

def use_color(setting: str) -> bool:
    """Choose whether to use color based on the command argument.

    Args:
        setting - Either `auto`, `always`, or `never`
    """
    if setting not in COLOR_CHOICES:
        raise ValueError(setting)
    return setting == 'always' or (setting == 'auto' and sys.stderr.isatty() and terminal_supports_color and (os.getenv('TERM') != 'dumb'))

def add_color_option(parser: argparse.ArgumentParser) -> None:
    parser.add_argument('--color', default=os.environ.get('PRE_COMMIT_COLOR', 'auto'), type=use_color, metavar='{' + ','.join(COLOR_CHOICES) + '}', help='Whether to use color in output.  Defaults to `%(default)s`.')