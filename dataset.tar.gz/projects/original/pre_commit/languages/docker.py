from __future__ import annotations
import hashlib
import json
import os
from collections.abc import Sequence
from pre_commit import lang_base
from pre_commit.prefix import Prefix
from pre_commit.util import CalledProcessError
from pre_commit.util import cmd_output_b
ENVIRONMENT_DIR = 'docker'
PRE_COMMIT_LABEL = 'PRE_COMMIT'
get_default_version = lang_base.basic_get_default_version
health_check = lang_base.basic_health_check
in_env = lang_base.no_env

def _is_in_docker() -> bool:
    try:
        with open('/proc/1/cgroup', 'rb') as f:
            return b'docker' in f.read()
    except FileNotFoundError:
        return False

def _get_container_id() -> str:
    with open('/proc/1/cgroup', 'rb') as f:
        for line in f.readlines():
            if line.split(b':')[1] == b'cpuset':
                return os.path.basename(line.split(b':')[2]).strip().decode()
    raise RuntimeError('Failed to find the container ID in /proc/1/cgroup.')

def _get_docker_path(path: str) -> str:
    if not _is_in_docker():
        return path
    container_id = _get_container_id()
    try:
        (_, out, _) = cmd_output_b('docker', 'inspect', container_id)
    except CalledProcessError:
        return path
    (container,) = json.loads(out)
    for mount in container['Mounts']:
        src_path = mount['Source']
        to_path = mount['Destination']
        if os.path.commonpath((path, to_path)) == to_path:
            return path.replace(to_path, src_path)
    return path

def md5(s: str) -> str:
    return hashlib.md5(s.encode()).hexdigest()

def docker_tag(prefix: Prefix) -> str:
    md5sum = md5(os.path.basename(prefix.prefix_dir)).lower()
    return f'pre-commit-{md5sum}'

def build_docker_image(prefix: Prefix, *, pull: bool) -> None:
    cmd: tuple[str, ...] = ('docker', 'build', '--tag', docker_tag(prefix), '--label', PRE_COMMIT_LABEL)
    if pull:
        cmd += ('--pull',)
    cmd += ('.',)
    lang_base.setup_cmd(prefix, cmd)

def install_environment(prefix: Prefix, version: str, additional_dependencies: Sequence[str]) -> None:
    lang_base.assert_version_default('docker', version)
    lang_base.assert_no_additional_deps('docker', additional_dependencies)
    directory = lang_base.environment_dir(prefix, ENVIRONMENT_DIR, version)
    build_docker_image(prefix, pull=True)
    os.mkdir(directory)

def get_docker_user() -> tuple[str, ...]:
    try:
        return ('-u', f'{os.getuid()}:{os.getgid()}')
    except AttributeError:
        return ()

def get_docker_tty(*, color: bool) -> tuple[str, ...]:
    return ('--tty',) if color else ()

def docker_cmd(*, color: bool) -> tuple[str, ...]:
    return ('docker', 'run', '--rm', *get_docker_tty(color=color), *get_docker_user(), '-v', f'{_get_docker_path(os.getcwd())}:/src:rw,Z', '--workdir', '/src')

def run_hook(prefix: Prefix, entry: str, args: Sequence[str], file_args: Sequence[str], *, is_local: bool, require_serial: bool, color: bool) -> tuple[int, bytes]:
    build_docker_image(prefix, pull=False)
    (entry_exe, *cmd_rest) = lang_base.hook_cmd(entry, args)
    entry_tag = ('--entrypoint', entry_exe, docker_tag(prefix))
    return lang_base.run_xargs((*docker_cmd(color=color), *entry_tag, *cmd_rest), file_args, require_serial=require_serial, color=color)