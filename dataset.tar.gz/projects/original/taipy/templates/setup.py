import json
import os
from setuptools import find_namespace_packages, find_packages, setup
with open('README.md', 'rb') as readme_file:
    readme = readme_file.read().decode('UTF-8')
version_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'version.json')
with open(version_path) as version_file:
    version = json.load(version_file)
    version_string = f"{version.get('major', 0)}.{version.get('minor', 0)}.{version.get('patch', 0)}"
    if (vext := version.get('ext')):
        version_string = f'{version_string}.{vext}'
test_requirements = ['pytest>=6.0']
setup(packages=find_namespace_packages(where='.') + find_packages(include=['taipy']), include_package_data=True, data_files=[('version', ['version.json'])], test_suite='tests', version=version_string)